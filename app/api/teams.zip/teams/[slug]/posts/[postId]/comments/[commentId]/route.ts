import { NextRequest, NextResponse } from 'next/server'
import { query } from '@/lib/db'
import { getViewerId } from '@/lib/auth/route-guards'
import { isTeamEditor, resolveTeamBySlug } from '../../../../_utils'

type Params = { params: { slug: string; postId: string; commentId: string } }

const isUuid = (s: string) =>
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s)

export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const { slug, postId, commentId } = params
    if (!isUuid(postId) || !isUuid(commentId)) {
      return NextResponse.json({ error: 'bad_id' }, { status: 400 })
    }

    const team = await resolveTeamBySlug(slug)
    if (!team) return NextResponse.json({ error: 'not_found' }, { status: 404 })

    const uid = await getViewerId(req)
    if (!uid) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })

    // пост точно принадлежит команде
    const post = await query('select 1 from team_posts where id=$1::uuid and team_id=$2 limit 1', [postId, team.id])
    if (!post.rowCount) return NextResponse.json({ error: 'not_found' }, { status: 404 })

    // получаем автора комментария
    const c = await query<{ user_id: string }>(
      'select user_id from team_post_comments where id=$1::uuid and post_id=$2::uuid limit 1',
      [commentId, postId]
    )
    if (!c.rowCount) return NextResponse.json({ error: 'not_found' }, { status: 404 })

    const isEditor = await isTeamEditor(team.id, uid)
    const isAuthor = c.rows[0].user_id === uid
    if (!isEditor && !isAuthor) return NextResponse.json({ error: 'forbidden' }, { status: 403 })

    await query('delete from team_post_comments where id=$1::uuid and post_id=$2::uuid', [commentId, postId])

    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error('comment DELETE error', e)
    return NextResponse.json({ error: 'internal' }, { status: 500 })
  }
}
