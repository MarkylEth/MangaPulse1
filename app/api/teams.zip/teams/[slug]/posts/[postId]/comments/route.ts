// app/api/teams/[slug]/posts/[postId]/comments/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { query } from '@/lib/db'
import { getViewerId } from '@/lib/auth/route-guards'
import { resolveTeamBySlug } from '../../_utils'

type Params = { params: { slug: string; postId: string } }

export async function GET(req: NextRequest, { params }: Params) {
  const { slug, postId } = params
  const team = await resolveTeamBySlug(slug)
  if (!team) return NextResponse.json({ error: 'not_found' }, { status: 404 })

  const { searchParams } = new URL(req.url)
  const limit = Math.min(parseInt(searchParams.get('limit') || '50', 10), 100)
  const offset = Math.max(parseInt(searchParams.get('offset') || '0', 10), 0)

  const r = await query<{
    id: string
    post_id: string
    user_id: string
    content: string
    created_at: string
    parent_id: string | null
    username: string | null
    avatar_url: string | null
  }>(
    `
    select
      c.id::text, c.post_id::text, c.user_id::text, c.content, c.created_at, c.parent_id::text,
      p.username, p.avatar_url
    from team_post_comments c
    left join profiles p on p.id = c.user_id
    where c.post_id = $1::uuid
    order by c.created_at asc
    limit $2 offset $3
    `,
    [postId, limit, offset]
  )

  return NextResponse.json({ items: r.rows, nextOffset: offset + r.rows.length, limit })
}

export async function POST(req: NextRequest, { params }: Params) {
  const { slug, postId } = params
  const team = await resolveTeamBySlug(slug)
  if (!team) return NextResponse.json({ error: 'not_found' }, { status: 404 })

  const uid = await getViewerId(req)
  if (!uid) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })

  const payload = await req.json().catch(() => ({} as any))
  const content = String(payload?.content ?? '').trim()
  const parent = payload?.parent_id ? String(payload.parent_id) : null
  if (!content) return NextResponse.json({ error: 'empty' }, { status: 400 })

  try {
    await query('begin')
    const ins = await query<{ id: string }>(
      `insert into team_post_comments (post_id, user_id, content, parent_id)
       values ($1::uuid, $2::uuid, $3, $4::uuid)
       returning id::text`,
      [postId, uid, content, parent]
    )
    await query(
      'update team_posts set comments_count = comments_count + 1 where id=$1::uuid',
      [postId]
    )
    await query('commit')
    return NextResponse.json({ ok: true, id: ins.rows[0].id })
  } catch (e) {
    await query('rollback').catch(() => {})
    console.error('comments POST error', e)
    return NextResponse.json({ error: 'internal' }, { status: 500 })
  }
}
