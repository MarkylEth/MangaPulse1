// app/api/teams/[slug]/posts/[postId]/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { query } from '@/lib/db'
import { getViewerId } from '@/lib/auth/route-guards'
import { resolveTeamBySlug, isTeamEditor } from '../../_utils'

type Params = { params: { slug: string; postId: string } }
const isUuid = (s: string) =>
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s)

export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const team = await resolveTeamBySlug(params.slug)
    if (!team) return NextResponse.json({ error: 'not_found' }, { status: 404 })
    const uid = await getViewerId(req)
    if (!uid) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })

    const canEditAny = await isTeamEditor(team.id, uid)
    const postId = params.postId
    if (!isUuid(postId)) return NextResponse.json({ error: 'bad_post_id' }, { status: 400 })

    if (canEditAny) {
      await query('delete from team_posts where id=$1::uuid and team_id=$2', [postId, team.id])
    } else {
      await query('delete from team_posts where id=$1::uuid and team_id=$2 and author_id=$3', [
        postId,
        team.id,
        uid,
      ])
    }

    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error('post DELETE error', e)
    return NextResponse.json({ error: 'internal' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    const team = await resolveTeamBySlug(params.slug)
    if (!team) return NextResponse.json({ error: 'not_found' }, { status: 404 })
    const uid = await getViewerId(req)
    if (!uid) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })

    const postId = params.postId
    if (!isUuid(postId)) return NextResponse.json({ error: 'bad_post_id' }, { status: 400 })

    const payload = await req.json().catch(() => ({} as any))
    const body = payload?.body !== undefined ? String(payload.body) : undefined
    const title = payload?.title !== undefined ? String(payload.title).slice(0, 256) : undefined
    const images = Array.isArray(payload?.images) ? payload.images.slice(0, 12) : undefined
    const featured = payload?.featured_image !== undefined ? String(payload.featured_image) : undefined
    const isPinned = payload?.is_pinned !== undefined ? !!payload.is_pinned : undefined

    const canEditAny = await isTeamEditor(team.id, uid)

    const sets: string[] = []
    const vals: any[] = []
    const push = (sql: string, v: any) => { sets.push(sql); vals.push(v) }

    if (body !== undefined) push(`body=$${vals.length + 1}`, body)
    if (title !== undefined) push(`title=$${vals.length + 1}`, title)
    if (images !== undefined) push(`images=$${vals.length + 1}`, images)
    if (featured !== undefined) push(`featured_image=$${vals.length + 1}`, featured)
    if (isPinned !== undefined) push(`is_pinned=$${vals.length + 1}`, isPinned)

    if (!sets.length) return NextResponse.json({ ok: true })

    vals.push(postId, team.id)
    let where = `id=$${vals.length - 1}::uuid and team_id=$${vals.length}`
    if (!canEditAny) { vals.push(uid); where += ` and author_id=$${vals.length}` }

    const sql = `update team_posts set ${sets.join(', ')}, updated_at=now() where ${where}`
    await query(sql, vals)

    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error('post PATCH error', e)
    return NextResponse.json({ error: 'internal' }, { status: 500 })
  }
}
