// app/api/teams/[slug]/follow/route.ts
import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { getAuthUser } from '@/lib/auth/route-guards';
import { resolveTeam } from '../_utils';

export async function POST(req: Request, { params }: { params: { slug: string } }) {
  const me = await getAuthUser(req);
  if (!me) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });

  const team = await resolveTeam(params.slug);
  if (!team) return NextResponse.json({ error: 'not_found' }, { status: 404 });

  const { follow } = await req.json().catch(() => ({ follow: true }));

  if (follow) {
    await query(
      `insert into team_followers (team_id, user_id)
       values ($1, $2::uuid)
       on conflict (team_id, user_id) do update set updated_at = now()`,
      [team.id, me.id],
    );
  } else {
    await query(
      `delete from team_followers where team_id = $1 and user_id::text = $2`,
      [team.id, me.id],
    );
  }

  const { rows } = await query<{ cnt: string }>(
    `select count(*)::int as cnt from team_followers where team_id = $1`,
    [team.id],
  );

  return NextResponse.json({ ok: true, i_follow: !!follow, followers_count: Number(rows[0]?.cnt || 0) });
}
