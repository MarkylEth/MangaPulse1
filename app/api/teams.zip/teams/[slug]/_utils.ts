import { query } from '@/lib/db'

export type TeamRow = {
  id: number
  slug: string | null
  name: string
  created_by: string
  created_at: string
  updated_at: string
  bio: string | null
  avatar_url: string | null
  banner_url: string | null
  telegram_url: string | null
  vk_url: string | null
  discord_url: string | null
  boosty_url: string | null
  tags: string[]          // text[]
  langs: string[]         // text[]
  likes_count: number
  followers_count: number
  started_at: string | null
  stats_projects: number
  stats_pages: number
  stats_inwork: number
  verified: boolean
  hiring_text: string | null
  hiring_enabled: boolean
}

/** Полная загрузка команды по slug — со всеми полями, нужными фронту */
export async function resolveTeamBySlug(slug: string): Promise<TeamRow | null> {
  const r = await query<TeamRow>(
    `
    select
      id, slug, name, created_by, created_at, updated_at,
      bio, avatar_url, banner_url,
      telegram_url, vk_url, discord_url, boosty_url,
      tags, langs,
      likes_count, followers_count,
      started_at,
      stats_projects, stats_pages, stats_inwork,
      verified, hiring_text, hiring_enabled
    from translator_teams
    where slug = $1
    limit 1
    `,
    [slug]
  )
  return r.rows[0] ?? null
}

/** Состоит ли пользователь в команде */
export async function isTeamMember(teamId: number, userId: string) {
  const r = await query<{ exists: boolean }>(
    `select exists(
       select 1 from translator_team_members
       where team_id=$1 and user_id=$2
     ) as exists`,
    [teamId, userId]
  )
  return !!r.rows[0]?.exists
}

/** Роли, которым разрешено редактирование профиля/состава */
const EDIT_ROLES = ['lead', 'editor'] as const

/** Может ли пользователь редактировать команду */
export async function isTeamEditor(teamId: number, userId: string) {
  // создатель → всегда может
  const created = await query<{ exists: boolean }>(
    `select exists(select 1 from translator_teams where id=$1 and created_by=$2) as exists`,
    [teamId, userId]
  )
  if (created.rows[0]?.exists) return true

  // участник с повышенной ролью
  const r = await query<{ exists: boolean }>(
    `select exists(
       select 1 from translator_team_members
       where team_id=$1 and user_id=$2 and role = any($3::text[])
     ) as exists`,
    [teamId, userId, EDIT_ROLES]
  )
  return !!r.rows[0]?.exists
}

/** Роль участника (или 'none') */
export async function getMemberRole(teamId: number, userId: string) {
  const created = await query<{ exists: boolean }>(
    `select exists(select 1 from translator_teams where id=$1 and created_by=$2) as exists`,
    [teamId, userId]
  )
  if (created.rows[0]?.exists) return 'leader'

  const r = await query<{ role: string }>(
    `select role from translator_team_members where team_id=$1 and user_id=$2 limit 1`,
    [teamId, userId]
  )
  return r.rows[0]?.role ?? 'none'
}

/** Совместимость со старыми импортами */
export { resolveTeamBySlug as resolveTeam }
