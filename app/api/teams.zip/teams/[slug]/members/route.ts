import { NextRequest, NextResponse } from 'next/server'
import { query } from '@/lib/db'
import { resolveTeamBySlug } from '../_utils'

type Params = { params: { slug: string } }

/** Список участников — для блока «Команда (N)» */
export async function GET(_req: NextRequest, { params }: Params) {
  const team = await resolveTeamBySlug(params.slug)
  if (!team) return NextResponse.json({ error: 'not_found' }, { status: 404 })

  const r = await query<{
    user_id: string
    role: string
    username: string | null
    avatar_url: string | null
  }>(
    `
    select m.user_id, m.role,
           p.username, p.avatar_url
    from translator_team_members m
    left join profiles p on p.id = m.user_id
    where m.team_id = $1
    order by
      case m.role
        when 'leader' then 0
        when 'owner'  then 1
        when 'lead'   then 2
        when 'editor' then 3
        when 'translator' then 4
        when 'typesetter' then 5
        else 6
      end,
      coalesce(p.username, '') asc
    `,
    [team.id]
  )

  const items = r.rows.map((x) => ({
    id: x.user_id,
    role: x.role,
    username: x.username,
    avatar: x.avatar_url,
  }))

  return NextResponse.json({ items, count: items.length })
}
